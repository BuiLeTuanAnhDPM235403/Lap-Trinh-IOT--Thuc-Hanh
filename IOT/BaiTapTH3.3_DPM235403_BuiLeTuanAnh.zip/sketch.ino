const int kPinButton1 = 4;
const int kPinLed = 13;

void setup() {
  pinMode(kPinButton1, INPUT);
  digitalWrite(kPinButton1, HIGH);
  pinMode(kPinLed, OUTPUT);
}

void loop() {
  if(digitalRead(kPinButton1) == LOW){
    digitalWrite(kPinLed,HIGH);
  }else{
    digitalWrite(kPinLed,LOW);
  }
} 