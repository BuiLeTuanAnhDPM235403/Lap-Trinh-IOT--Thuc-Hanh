/*
 * Created by ArduinoGetStarted.com
 *
 * This example code is in the public domain
 *
 * Tutorial page: https://arduinogetstarted.com/tutorials/arduino-lm35-temperature-sensor
 */

const int kPinButton1 = 3;
const int kPinButton2 = 2;
const int kPinLed = 13;

int ledBrightness = 128;

void setup() {
  pinMode(kPinButton1, INPUT);
  pinMode(kPinButton2, INPUT);
  pinMode(kPinLed, OUTPUT);
  digitalWrite(kPinButton1, HIGH);
  digitalWrite(kPinButton2, HIGH);
}

void loop() {
  if (digitalRead(kPinButton1) == LOW) {
    ledBrightness--;
  } 
  if (digitalRead(kPinButton2) == LOW) {
    ledBrightness++;
  }
  ledBrightness = constrain(ledBrightness, 0, 255);
  analogWrite(kPinLed, ledBrightness);
  delay(1);
}