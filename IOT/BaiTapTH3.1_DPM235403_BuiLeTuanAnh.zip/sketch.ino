void setup() {
  // Khởi tạo giao tiếp nối tiếp tại 9.600 bit mỗi giây
  Serial.begin(9600);
}

void loop() {
  // Đọc ngõ ra tại chân A0
  int sensorValue = analogRead(A0);
  
  // In giá trị đọc được
  Serial.println(sensorValue);
  
  // Tạo trễ để giá trị đọc ổn định
  delay(1);
}